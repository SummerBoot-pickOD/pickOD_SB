-- 테이블 일괄 삭제
DROP TABLE "COMMENTS" CASCADE CONSTRAINTS;
DROP TABLE "JNL_DAY" CASCADE CONSTRAINTS;
DROP TABLE "JNL_IMGS" CASCADE CONSTRAINTS;
DROP TABLE "JOURNAL" CASCADE CONSTRAINTS;
DROP TABLE "JOURNAL_PICK" CASCADE CONSTRAINTS;
DROP TABLE "LIKED" CASCADE CONSTRAINTS;
DROP TABLE "MEMBER" CASCADE CONSTRAINTS;
DROP TABLE "MEMBER_IMGS" CASCADE CONSTRAINTS;
DROP TABLE "MESSAGE" CASCADE CONSTRAINTS;
DROP TABLE "MESSAGE_STATUS" CASCADE CONSTRAINTS;
DROP TABLE "PLACE" CASCADE CONSTRAINTS;
DROP TABLE "PLACE_IMGS" CASCADE CONSTRAINTS;
DROP TABLE "PLACE_PICK" CASCADE CONSTRAINTS;
DROP TABLE "PLAN" CASCADE CONSTRAINTS;
DROP TABLE "PLAN_PLACE" CASCADE CONSTRAINTS;
DROP TABLE "REPORT" CASCADE CONSTRAINTS;
DROP TABLE "SANCTION" CASCADE CONSTRAINTS;
DROP TABLE "TEMPLATE" CASCADE CONSTRAINTS;
DROP TABLE "TEMPLATE_PICK" CASCADE CONSTRAINTS;
DROP TABLE "TEMP_DAY" CASCADE CONSTRAINTS;
DROP TABLE "TEMP_IMGS" CASCADE CONSTRAINTS;

--테이블 생성
CREATE TABLE MEMBER_IMGS(
                            MEMBER_IMGS_ID NUMBER PRIMARY KEY,
                            MEMBER_IMGS_GUID VARCHAR2(32),
                            FILE_NAME VARCHAR2(100),                        -- 이미지 데이터 (VARCHAR2(100) 타입)
                            uploadPath varchar2(200) not null,
                            MEMBER_IMG_TYPE VARCHAR2(10) NOT NULL,     -- 이미지 유형 ('USER' 또는 'DEFAULT')
                            MEMBER_IMG_URL VARCHAR2(255),              -- 웹사이트 기본 제공 이미지일 경우의 URL (NULL 가능)
                            DEFAULT_YN CHAR(1) DEFAULT 'N',      -- 기본 이미지 여부 ('Y' 또는 'N')
                            CONSTRAINT chk_DEFAULT_YN CHECK (DEFAULT_YN IN ( 'Y', 'N'))
);

-- 회원 테이블
CREATE TABLE MEMBER (
                        MEMBER_NUM NUMBER PRIMARY KEY,
                        MEMBER_ID VARCHAR2(255) UNIQUE NOT NULL,
                        MEMBER_PASSWORD VARCHAR2(255) NOT NULL,
                        MEMBER_NICKNAME VARCHAR2(200) UNIQUE NOT NULL,
                        MEMBER_ADDRESS VARCHAR2(500),
                        MEMBER_BDATE DATE,
                        MEMBER_GENDER CHAR(1),
                        MEMBER_IMG_YN char(1) NOT NULL,
                        MEMBER_IMGS_ID NUMBER,  -- 프로필 사진 ID
                        CONSTRAINT fk_MEMBER_IMGS FOREIGN KEY (MEMBER_IMGS_ID) REFERENCES MEMBER_IMGS(MEMBER_IMGS_ID),
                        CONSTRAINT chk_MEMBER_IMG_YN CHECK (MEMBER_IMG_YN IN ('Y', 'N'))
);


-- 메시지 테이블
CREATE TABLE MESSAGE(
                        MSG_ID NUMBER PRIMARY KEY,
                        MSG_SENDER NUMBER REFERENCES MEMBER(MEMBER_NUM),
                        MSG_RECIPIENT NUMBER REFERENCES MEMBER(MEMBER_NUM),
                        MSG_CONTENT VARCHAR2(1000) NOT NULL,
                        MSG_SENT_TIME  DATE NOT NULL
);

-- 메시지 상태 테이블
CREATE TABLE MESSAGE_STATUS(
                               STATUS_ID NUMBER PRIMARY KEY,
                               MSG_ID NUMBER REFERENCES MESSAGE(MSG_ID),
                               MEMBER_NUM NUMBER REFERENCES MEMBER(MEMBER_NUM),
                               MSG_BOX CHAR(1) NOT NULL,
                               MSG_READ NUMBER DEFAULT 0,
                               MSG_TRASHED_DATE DATE,
                               CONSTRAINT chk_msg_box CHECK (MSG_BOX IN ('I', 'S', 'T'))
);

-- 장소 테이블 작성자가 필요할듯. 일단은 DEFAULT1로 넣음
CREATE TABLE PLACE(
                      PLACE_ID NUMBER PRIMARY KEY,
                      PLACE_NAME VARCHAR2(255)  NOT NULL,
                      PLACE_ADDRESS VARCHAR2(500) NOT NULL,
                      PLACE_VIEWS NUMBER DEFAULT 0 NOT NULL,
                      PLACE_DETAILS VARCHAR2(500) NOT NULL,
                      PLACE_URL VARCHAR2(255),
                      PLACE_PHONENUM VARCHAR2(20),
                      PLACE_COST VARCHAR2(255),
                      PLACE_OP_HOUR VARCHAR2(255),
                      PLACE_RELATED1 VARCHAR2(255) NOT NULL,
                      PLACE_RELATED2 VARCHAR2(255),
                      PLACE_RELATED3 VARCHAR2(255),
                      PLACE_LAT NUMBER(10,6),
                      PLACE_LONG NUMBER(10,6),
                      MEMBER_NUM NUMBER DEFAULT 1,
                      CONSTRAINT fk_place_member FOREIGN KEY (MEMBER_NUM) REFERENCES MEMBER(MEMBER_NUM)
);


--장소이미지 테이블
CREATE TABLE PLACE_IMGS(
                           PLACE_IMGS_ID NUMBER PRIMARY KEY,
                           PLACE_IMGS_GUID VARCHAR2(32),
                           FILE_NAME VARCHAR2(100) NOT NULL,
                           uploadPath varchar2(200) not null,
                           PLACE_ID NUMBER REFERENCES PLACE(PLACE_ID)
);

-- 여행일지 테이블
CREATE TABLE JOURNAL(
                        JNL_NUM NUMBER PRIMARY KEY,
                        JNL_TITLE VARCHAR2(100) NOT NULL,
                        MEMBER_NUM NUMBER REFERENCES MEMBER(MEMBER_NUM),
                        JNL_VIEWS  NUMBER NOT NULL,
                        JNL_MEMO VARCHAR2(1000),
                        JNL_CREATE_DATE DATE NOT NULL,
                        JNL_UPDATE_DATE DATE NOT NULL,
                        JNL_PERIOD VARCHAR2(100) NOT NULL,
                        JNL_TAG VARCHAR2(100) NOT NULL,
                        JNL_THEME VARCHAR2(100) NOT NULL,
                        JNL_AREA VARCHAR2(50) NOT NULL
);

-- 여행일지 콘텐츠 테이블
CREATE TABLE JNL_DAY(
                        JNL_NUM NUMBER,
                        JNL_DAY NUMBER,
                        JNL_PLACE_ORDER NUMBER NOT NULL,
                        JNL_CONTENTS VARCHAR2(4000),
                        PLACE_ID NUMBER REFERENCES PLACE(PLACE_ID),
                        CONSTRAINT PK_JNL_DAY PRIMARY KEY(JNL_NUM, JNL_DAY, JNL_PLACE_ORDER),
                        CONSTRAINT fk_jnl_num FOREIGN KEY (JNL_NUM) REFERENCES JOURNAL(JNL_NUM)
);

--여행일지 이미지
CREATE TABLE JNL_IMGS(
                         JNL_IMGS_ID NUMBER PRIMARY KEY,
                         JNL_IMGS_GUID VARCHAR2(32),
                         FILE_NAME VARCHAR2(100) NOT NULL,
                         uploadPath VARCHAR2(200) NOT NULL,
                         JNL_IMGS_ORDER NUMBER NOT NULL,
                         JNL_NUM NUMBER,
                         JNL_DAY NUMBER,
                         JNL_PLACE_ORDER NUMBER, -- 추가된 컬럼
                         PLACE_ID NUMBER REFERENCES PLACE(PLACE_ID),
                         CONSTRAINT fk_jnl_imgs FOREIGN KEY (JNL_NUM, JNL_DAY, JNL_PLACE_ORDER) REFERENCES JNL_DAY(JNL_NUM, JNL_DAY, JNL_PLACE_ORDER)
);



-- 계획 테이블
CREATE TABLE PLAN(
                     PLAN_ID NUMBER PRIMARY KEY,
                     MEMBER_NUM NUMBER NOT NULL,
                     PLAN_TITLE VARCHAR2(50) NOT NULL,
                     PLAN_START_DATE DATE NOT NULL,
                     PLAN_END_DATE DATE NOT NULL,
                     CONSTRAINT fk_PLAN_member FOREIGN KEY (MEMBER_NUM) REFERENCES MEMBER(MEMBER_NUM)
);

-- 계획 장소 테이블
CREATE TABLE PLAN_PLACE(
                           PLAN_ID NUMBER,
                           PLAN_DAY NUMBER,
                           PLAN_ORDER NUMBER,
                           PLAN_DATE DATE NOT NULL,
                           PLACE_ID NUMBER,
                           PLAN_MEMO VARCHAR2(100),
                           CONSTRAINT pk_plan_place PRIMARY KEY(PLAN_ID, PLAN_DAY, PLAN_ORDER),
                           CONSTRAINT fk_plan_ID FOREIGN KEY (PLAN_ID) REFERENCES PLAN(PLAN_ID),
                           CONSTRAINT fk_plan_place_id FOREIGN KEY (PLACE_ID) REFERENCES PLACE(PLACE_ID)
);

-- 댓글 테이블
CREATE TABLE COMMENTS(
                         CMT_ID NUMBER PRIMARY KEY,
                         MEMBER_NUM NUMBER,
                         CMT_POST_TYPE CHAR(1),
                         CMT_POST_ID NUMBER,
                         CMT_CONTENTS VARCHAR2(100) NOT NULL,
                         CONSTRAINT fk_COMMENTS_member FOREIGN KEY (MEMBER_NUM) REFERENCES MEMBER(MEMBER_NUM),
                         CONSTRAINT chk_CMT_post_type CHECK (CMT_POST_TYPE IN ('T','J','P'))
);

-- 좋아요 테이블
CREATE TABLE LIKED(
                      MEMBER_NUM NUMBER,
                      CMT_ID NUMBER,
                      CONSTRAINT pk_LIKED PRIMARY KEY (MEMBER_NUM, CMT_ID),
                      CONSTRAINT fk_LIKED_member FOREIGN KEY (MEMBER_NUM) REFERENCES MEMBER(MEMBER_NUM),
                      CONSTRAINT fk_LIKED_COMMENTS FOREIGN KEY (CMT_ID) REFERENCES COMMENTS(CMT_ID)
);


-- 템플릿 테이블 --작성자 추가
CREATE TABLE TEMPLATE(
                         TEMP_ID NUMBER PRIMARY KEY,
                         TEMP_TITLE VARCHAR2(100) NOT NULL,
                         TEMP_PERIOD VARCHAR2(100) NOT NULL,
                         TEMP_VIEWS NUMBER NOT NULL,
                         TEMP_TAG VARCHAR2(100) NOT NULL,
                         TEMP_THEME VARCHAR2(100) NOT NULL,
                        TEMP_AREA VARCHAR2(100) NOT NULL,
                         JNL_NUM NUMBER REFERENCES JOURNAL(JNL_NUM),--TEMPLATE로옮김
                         MEMBER_NUM NUMBER DEFAULT 1 REFERENCES MEMBER(MEMBER_NUM) -- 관리자 삭제 방지
);

-- 템플릿의 하루 계획 테이블
CREATE TABLE TEMP_DAY(
                         TEMP_ID NUMBER,
                         TEMP_DAY_NUM NUMBER NOT NULL,
                         TEMP_PLACE_ORDER NUMBER NOT NULL,
                         PLACE_ID NUMBER REFERENCES PLACE(PLACE_ID),
                         TEMP_CONTENTS CLOB,
                         TEMP_REC1 VARCHAR2(100) NOT NULL,
                         TEMP_REC2 VARCHAR2(100),
                         TEMP_REC3 VARCHAR2(100),
                         CONSTRAINT PK_TEMP_DAY PRIMARY KEY(TEMP_ID),
                         CONSTRAINT fk_temp_id FOREIGN KEY (TEMP_ID) REFERENCES TEMPLATE(TEMP_ID)
);

-- TEMPLATE IMG테이블
CREATE TABLE TEMP_IMGS(
                          TEMP_IMGS_ID NUMBER PRIMARY KEY,
                          TEMP_IMGS_GUID VARCHAR2(32),
                          FILE_NAME VARCHAR2(100),
                          uploadPath varchar2(200) not null,
                          TEMP_IMGS_ORDER NUMBER NOT NULL,
                          PLACE_ID NUMBER REFERENCES PLACE(PLACE_ID),
                          TEMP_ID NUMBER,
                          TEMP_DAY_NUM NUMBER,
                          CONSTRAINT fk_TEMP_imgs FOREIGN KEY (TEMP_ID) REFERENCES TEMP_DAY(TEMP_ID)
);


-- 신고 테이블
CREATE TABLE REPORT(
                       REPORT_ID NUMBER PRIMARY KEY,
                       REPORT_POST_TYPE CHAR(1) NOT NULL,
                       REPORT_POST_ID NUMBER NOT NULL,
                       WRITER_ID NUMBER NOT NULL,
                       REPORTER_ID NUMBER NOT NULL,
                       REPORT_TYPE VARCHAR2(50) NOT NULL,
                       REPORT_DETAIL VARCHAR2(200),
                       REPORT_SOLVED NUMBER(1) DEFAULT 0,
                       REPORT_DATE DATE NOT NULL,
                       CONSTRAINT fk_writer FOREIGN KEY (WRITER_ID) REFERENCES MEMBER(MEMBER_NUM),
                       CONSTRAINT fk_reporter FOREIGN KEY (REPORTER_ID) REFERENCES MEMBER(MEMBER_NUM),
                       CONSTRAINT chk_report_post_type CHECK (REPORT_POST_TYPE IN ('T','J','P','C','M')),
                       CONSTRAINT chk_solved CHECK (REPORT_SOLVED IN (0,1))
);

-- 제재 테이블
CREATE TABLE SANCTION(
                         SANCTION_NUM NUMBER PRIMARY KEY,
                         MEMBER_NUM NUMBER,
                         SANCTION_CNT NUMBER NOT NULL,
                         SANCTION_REASON VARCHAR2(100) NOT NULL,
                         SANCTION_NOTE VARCHAR2(200),
                         SANCTION_START_DATE DATE NOT NULL,
                         SANCTION_END_DATE DATE NOT NULL,
                         REPORT_ID NUMBER NOT NULL,
                         FOREIGN KEY (MEMBER_NUM) REFERENCES MEMBER(MEMBER_NUM),
                         FOREIGN KEY (REPORT_ID) REFERENCES REPORT(REPORT_ID)
);

-- 찜하기 기능 테이블들
-- 템플릿에 대한 찜하기 테이블
CREATE TABLE TEMPLATE_PICK (
                               PICK_ID NUMBER PRIMARY KEY,
                               MEMBER_NUM NUMBER NOT NULL,
                               TEMP_ID NUMBER NOT NULL,
                               PICK_DATE DATE DEFAULT SYSDATE,
                               FOREIGN KEY (MEMBER_NUM) REFERENCES MEMBER(MEMBER_NUM),
                               FOREIGN KEY (TEMP_ID) REFERENCES TEMPLATE(TEMP_ID)
);

-- 여행일지에 대한 찜하기 테이블
CREATE TABLE JOURNAL_PICK (
                              PICK_ID NUMBER PRIMARY KEY,
                              MEMBER_NUM NUMBER NOT NULL,
                              JNL_NUM NUMBER NOT NULL,
                              PICK_DATE DATE DEFAULT SYSDATE,
                              FOREIGN KEY (MEMBER_NUM) REFERENCES MEMBER(MEMBER_NUM),
                              FOREIGN KEY (JNL_NUM) REFERENCES JOURNAL(JNL_NUM)
);

-- 장소에 대한 찜하기 테이블
CREATE TABLE PLACE_PICK (
                            PICK_ID NUMBER PRIMARY KEY,
                            MEMBER_NUM NUMBER NOT NULL,
                            PLACE_ID NUMBER NOT NULL,
                            PICK_DATE DATE DEFAULT SYSDATE,
                            FOREIGN KEY (MEMBER_NUM) REFERENCES MEMBER(MEMBER_NUM),
                            FOREIGN KEY (PLACE_ID) REFERENCES PLACE(PLACE_ID)
);